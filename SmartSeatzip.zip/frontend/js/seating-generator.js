/* ==========================================
   SMARTSEAT
   SEATING GENERATOR
   COMPLETE & CLEAN VERSION
========================================== */

console.log("🚀 SmartSeat Seating Generator Loaded");


/* ==========================================
   API
========================================== */

const EXAMS_API =
    "http://localhost:5000/api/exams";

const ROOMS_API =
    "http://localhost:5000/api/rooms";

const STUDENTS_API =
    "http://localhost:5000/api/students";

const SEATING_API = "http://localhost:5000/api/seating";

/* ==========================================
   DATA
========================================== */

let exams = [];
let masterStudents = [];
let students = [];
let rooms = [];
let seating = [];

let selectedExamId = "";
let selectedExam = null;
let examSelect = null;


/* ==========================================
   AUTH
========================================== */

function getToken() {

    return localStorage.getItem("token");

}


function getHeaders() {

    const token = getToken();

    return {

        "Content-Type": "application/json",

        ...(token
            ? {
                Authorization:
                    `Bearer ${token}`
            }
            : {})

    };

}


/* ==========================================
   ALERT
========================================== */

function showAlert(
    title,
    text,
    icon = "info"
) {

    if (
        typeof Swal !== "undefined"
    ) {

        return Swal.fire({

            title,
            text,
            icon

        });

    }

    alert(
        `${title}\n\n${text}`
    );

}


/* ==========================================
   LOAD EXAMS
========================================== */

async function loadExams() {

    try {

        const response =
            await fetch(
                EXAMS_API,
                {
                    method: "GET",
                    headers: getHeaders()
                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Unable to load examinations."
            );

        }


        if (Array.isArray(data)) {

            exams = data;

        }

        else if (
            Array.isArray(data.exams)
        ) {

            exams = data.exams;

        }

        else if (
            Array.isArray(data.data)
        ) {

            exams = data.data;

        }

        else {

            exams = [];

        }


        populateExamList();


        console.log(
            `✅ ${exams.length} examinations loaded.`
        );

    }

    catch (error) {

        console.error(
            "❌ Exam loading error:",
            error
        );

        exams = [];

        showAlert(
            "Unable to Load Exams",
            error.message,
            "error"
        );

    }

}


/* ==========================================
   EXAM DROPDOWN
========================================== */

function populateExamList() {

    if (!examSelect) return;


    examSelect.innerHTML = `

        <option value="">
            Select Examination
        </option>

    `;


    exams.forEach(
        exam => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                exam._id;


            const examName =
                exam.examName ||
                "Unnamed Examination";


            const semester =
                exam.semester ||
                "";


            const date =
                exam.examDate
                    ? new Date(
                        exam.examDate
                    ).toLocaleDateString(
                        "en-IN"
                    )
                    : "";


            const session =
                exam.session ||
                "";


            option.textContent =
                `${examName} - Semester ${semester}` +
                `${date ? " - " + date : ""}` +
                `${session ? " - " + session : ""}`;


            examSelect.appendChild(
                option
            );

        }
    );

}


/* ==========================================
   LOAD ROOMS
========================================== */

async function loadRooms() {

    try {

        const response =
            await fetch(
                ROOMS_API,
                {
                    method: "GET",
                    headers: getHeaders()
                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Unable to load rooms."
            );

        }


        if (Array.isArray(data)) {

            rooms = data;

        }

        else if (
            Array.isArray(data.rooms)
        ) {

            rooms = data.rooms;

        }

        else if (
            Array.isArray(data.data)
        ) {

            rooms = data.data;

        }

        else {

            rooms = [];

        }


        console.log(
            `✅ ${rooms.length} rooms loaded.`
        );

    }

    catch (error) {

        console.error(
            "❌ Room loading error:",
            error
        );

        rooms = [];

        showAlert(
            "Unable to Load Rooms",
            error.message,
            "error"
        );

    }

}


/* ==========================================
   LOAD MASTER STUDENTS
========================================== */

async function loadMasterStudents() {

    try {

        const response =
            await fetch(
                STUDENTS_API,
                {
                    method: "GET",
                    headers: getHeaders()
                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Unable to load students."
            );

        }


        if (Array.isArray(data)) {

            masterStudents = data;

        }

        else if (
            Array.isArray(data.students)
        ) {

            masterStudents =
                data.students;

        }

        else if (
            Array.isArray(data.data)
        ) {

            masterStudents =
                data.data;

        }

        else {

            masterStudents = [];

        }


        console.log(
            `✅ ${masterStudents.length} master students loaded.`
        );

    }

    catch (error) {

        console.error(
            "❌ Master students loading error:",
            error
        );

        masterStudents = [];

        showAlert(
            "Unable to Load Students",
            error.message,
            "error"
        );

    }

}


/* ==========================================
   ADDITIONAL ENTRIES
========================================== */

function loadAdditionalEntries() {

    try {

        const saved =
            JSON.parse(
                localStorage.getItem(
                    "nominalRolls"
                )
            );


        if (!Array.isArray(saved)) {

            return [];

        }


        return saved;

    }

    catch (error) {

        console.error(
            "❌ Additional Entries error:",
            error
        );

        return [];

    }

}


/* ==========================================
   NORMALIZE DEPARTMENT
========================================== */

function normalizeDepartment(
    department
) {

    return String(
        department || ""
    )
        .trim()
        .toUpperCase();

}


/* ==========================================
   REGISTER NUMBER
========================================== */

function getRegisterNumber(
    student
) {

    return String(
        student?.registerNumber ||
        student?.regNo ||
        ""
    )
        .trim()
        .toUpperCase();

}


/* ==========================================
   GET EXAM DEPARTMENTS
========================================== */

function getExamDepartments(
    exam
) {

    const departments = [];


    if (
        Array.isArray(
            exam?.subjects
        )
    ) {

        exam.subjects.forEach(
            subject => {

                if (
                    Array.isArray(
                        subject.departments
                    )
                ) {

                    subject.departments.forEach(
                        department => {

                            const normalized =
                                normalizeDepartment(
                                    department
                                );


                            if (
                                normalized &&
                                !departments.includes(
                                    normalized
                                )
                            ) {

                                departments.push(
                                    normalized
                                );

                            }

                        }
                    );

                }

            }
        );

    }


    /* --------------------------------------
       OLD EXAM COMPATIBILITY
    -------------------------------------- */

    if (
        departments.length === 0 &&
        Array.isArray(
            exam?.departments
        )
    ) {

        exam.departments.forEach(
            department => {

                const normalized =
                    normalizeDepartment(
                        department
                    );


                if (
                    normalized &&
                    !departments.includes(
                        normalized
                    )
                ) {

                    departments.push(
                        normalized
                    );

                }

            }
        );

    }


    return departments;

}


/* ==========================================
   ALLOWED MASTER DEPARTMENTS
========================================== */

function getAllowedStudentDepartments(
    examDepartments
) {

    const allowed =
        new Set();


    examDepartments.forEach(
        department => {

            /*
               Examination uses:

               BCOM.CA/CP

               Master students use:

               BCOM.CA
               BCOM.CP
            */

            if (
                department ===
                "BCOM.CA/CP"
            ) {

                allowed.add(
                    "BCOM.CA"
                );

                allowed.add(
                    "BCOM.CP"
                );

            }

            else {

                allowed.add(
                    department
                );

            }

        }
    );


    return allowed;

}


/* ==========================================
   GET ADDITIONAL STUDENTS
========================================== */

function getAdditionalStudents(
    examId
) {

    const entries =
        loadAdditionalEntries();


    const currentEntry =
        entries.find(
            entry =>
                String(
                    entry.examId
                ) ===
                String(
                    examId
                )
        );


    if (
        currentEntry &&
        Array.isArray(
            currentEntry.students
        )
    ) {

        return currentEntry.students;

    }


    return [];

}

/* ==========================================
   GET ID VALUE
========================================== */

function getIdValue(value) {

    if (!value) {
        return "";
    }


    if (
        typeof value === "object" &&
        value._id
    ) {

        return String(
            value._id
        );

    }


    return String(
        value
    );

}


/* ==========================================
   GET STUDENT BATCH ID
========================================== */

function getStudentBatchId(student) {

    if (!student) {
        return "";
    }


    if (student.batch) {

        if (
            typeof student.batch ===
            "object" &&
            student.batch._id
        ) {

            return String(
                student.batch._id
            );

        }


        return String(
            student.batch
        );

    }


    if (student.batchId) {

        return String(
            student.batchId
        );

    }


    return "";

}


/* ==========================================
   GET PAPER KEY
========================================== */

function getPaperKey(paper) {

    if (!paper) {
        return "";
    }


    const code =
        String(
            paper.subjectCode || ""
        )
            .trim()
            .toUpperCase();


    const name =
        String(
            paper.subjectName || ""
        )
            .trim()
            .toLowerCase()
            .replace(
                /\s+/g,
                " "
            );


    /*
       Prefer subject code.

       If no code exists, use subject name.
    */

    return (
        code ||
        name
    );

}


/* ==========================================
   FIND STUDENT EXAM PAPER
========================================== */

function findStudentExamPaper(
    student,
    exam
) {

    if (
        !student ||
        !exam ||
        !Array.isArray(
            exam.subjects
        )
    ) {

        return null;

    }


    const studentBatchId =
        getStudentBatchId(
            student
        );


    const studentSemester =
        Number(
            student.semester
        );


    const studentDepartment =
        normalizeDepartment(
            student.department
        );


    if (
        !studentBatchId ||
        !studentSemester ||
        !studentDepartment
    ) {

        return null;

    }


    const paper =
        exam.subjects.find(
            subject => {

                const subjectBatchId =
                    getIdValue(
                        subject.batch
                    );


                const subjectSemester =
                    Number(
                        subject.semester
                    );


                const subjectDepartment =
                    normalizeDepartment(
                        subject.department
                    );


                /*
                   Normal department match
                */

                if (
                    subjectDepartment ===
                    studentDepartment
                ) {

                    return (

                        subjectBatchId ===
                        studentBatchId

                        &&

                        subjectSemester ===
                        studentSemester

                    );

                }


                /*
                   Backward compatibility
                   for BCOM.CA/CP.
                */

                if (
                    subjectDepartment ===
                    "BCOM.CA/CP"
                ) {

                    return (

                        (
                            studentDepartment ===
                                "BCOM.CA"

                            ||

                            studentDepartment ===
                                "BCOM.CP"
                        )

                        &&

                        subjectBatchId ===
                        studentBatchId

                        &&

                        subjectSemester ===
                        studentSemester

                    );

                }


                return false;

            }
        );


    return paper || null;

}


/* ==========================================
   GET STUDENT PAPER KEY
========================================== */

function getStudentPaperKey(
    student
) {

    if (
        !student ||
        !student.__paper
    ) {

        return "";

    }


    return getPaperKey(
        student.__paper
    );

}

/* ==========================================
   UPDATE SELECTED EXAM
========================================== */

function updateSelectedExam() {

    if (!examSelect) return;


    selectedExamId =
        examSelect.value;


    selectedExam =
        exams.find(
            exam =>
                String(exam._id) ===
                String(selectedExamId)
        );


    /* --------------------------------------
       NO EXAM SELECTED
    -------------------------------------- */

    if (!selectedExam) {

        students = [];

        seating = [];

        localStorage.removeItem(
            "smartseatGeneratedReport"
        );

        updateStatistics();

        updateAdditionalStatus();

        renderSeatingTable();

        return;

    }


    /* --------------------------------------
       PARTICIPATING BATCH + SEMESTERS
    -------------------------------------- */

    const participating =
        Array.isArray(
            selectedExam.participatingSemesters
        )
            ? selectedExam.participatingSemesters
            : [];


    if (!participating.length) {

        students = [];

        seating = [];

        updateStatistics();

        renderSeatingTable();

        showAlert(
            "No Participating Semesters",
            "This examination does not have any participating batch and semester configured.",
            "warning"
        );

        return;

    }


    /* --------------------------------------
       EXAM SUBJECTS
    -------------------------------------- */

    const examSubjects =
        Array.isArray(
            selectedExam.subjects
        )
            ? selectedExam.subjects
            : [];


    if (!examSubjects.length) {

        students = [];

        seating = [];

        updateStatistics();

        renderSeatingTable();

        showAlert(
            "No Examination Subjects",
            "This examination does not have any subjects configured.",
            "warning"
        );

        return;

    }


    /* --------------------------------------
       FIND ELIGIBLE STUDENTS
    -------------------------------------- */

    const examStudents =
        [];


    masterStudents.forEach(
        student => {

            const studentBatchId =
                getStudentBatchId(
                    student
                );


            const studentSemester =
                Number(
                    student.semester
                );


            const studentDepartment =
                normalizeDepartment(
                    student.department
                );


            if (
                !studentBatchId ||
                !studentSemester ||
                !studentDepartment
            ) {

                return;

            }


            /* --------------------------------
               Check Batch + Semester
            -------------------------------- */

            const participant =
                participating.find(
                    item => {

                        const participantBatchId =
                            getIdValue(
                                item.batch
                            );


                        return (

                            participantBatchId ===
                            studentBatchId

                            &&

                            Number(
                                item.semester
                            ) ===
                            studentSemester

                        );

                    }
                );


            if (!participant) {

                return;

            }


            /* --------------------------------
               Find EXACT examination paper
            -------------------------------- */

            const paper =
                findStudentExamPaper(
                    student,
                    selectedExam
                );


            if (!paper) {

                /*
                   Don't add the student yet.

                   We handle missing papers
                   below so the generator can
                   stop safely.
                */

                examStudents.push({

                    ...student,

                    __paperMissing: true,

                    __paper: null

                });

                return;

            }


            examStudents.push({

                ...student,

                __paperMissing: false,

                __paper: paper

            });

        }
    );


    /* --------------------------------------
       CHECK MISSING PAPER INFORMATION
    -------------------------------------- */

    const studentsWithoutPaper =
        examStudents.filter(
            student =>
                student.__paperMissing
        );


    if (
        studentsWithoutPaper.length > 0
    ) {

        console.error(
            "Students without examination paper:",
            studentsWithoutPaper
        );

        students = [];

        seating = [];

        updateStatistics();

        renderSeatingTable();

        showAlert(
            "Paper Information Missing",
            `${studentsWithoutPaper.length} student(s) could not be matched to an examination paper for their batch, semester and department. Seating cannot be generated safely.`,
            "error"
        );

        return;

    }


    /* --------------------------------------
       ADDITIONAL ENTRIES
    -------------------------------------- */

    const additionalStudents =
        getAdditionalStudents(
            selectedExam._id
        );


    /*
       Additional Entries must also have
       enough information to enforce the
       same-paper rule.

       We don't silently put unknown-paper
       students into the arrangement.
    */

    additionalStudents.forEach(
        student => {

            const paper =
                findStudentExamPaper(
                    student,
                    selectedExam
                );


            student.__paper =
                paper || null;


            student.__paperMissing =
                !paper;

        }
    );


    const additionalWithoutPaper =
        additionalStudents.filter(
            student =>
                student.__paperMissing
        );


    if (
        additionalWithoutPaper.length > 0
    ) {

        console.warn(
            "Additional entries without paper information:",
            additionalWithoutPaper
        );

        /*
           Don't add them to the seating pool.
           They can be handled later through
           Additional Entries with paper data.
        */

    }


    /* --------------------------------------
       COMBINE WITHOUT DUPLICATES
    -------------------------------------- */

    const combinedStudents =
        [
            ...examStudents
        ];


    const existingRegisters =
        new Set();


    examStudents.forEach(
        student => {

            const registerNumber =
                getRegisterNumber(
                    student
                );


            if (registerNumber) {

                existingRegisters.add(
                    registerNumber
                );

            }

        }
    );


    additionalStudents
        .filter(
            student =>
                !student.__paperMissing
        )
        .forEach(
            student => {

                const registerNumber =
                    getRegisterNumber(
                        student
                    );


                if (
                    registerNumber &&
                    !existingRegisters.has(
                        registerNumber
                    )
                ) {

                    combinedStudents.push(
                        student
                    );

                    existingRegisters.add(
                        registerNumber
                    );

                }

            }
        );


    /* --------------------------------------
       SAVE CURRENT STUDENTS
    -------------------------------------- */

    students =
        combinedStudents;


    /* --------------------------------------
       CLEAR OLD SEATING
    -------------------------------------- */

    seating = [];


    localStorage.removeItem(
        "smartseatGeneratedReport"
    );


    updateStatistics();

    updateAdditionalStatus();

    renderSeatingTable();


    /* --------------------------------------
       DEBUG INFORMATION
    -------------------------------------- */

    console.log(
        "================================"
    );

    console.log(
        "Selected Examination:",
        selectedExam.examName
    );

    console.log(
        "Participating Batch/Semesters:",
        participating
    );

    console.log(
        "Exam Subjects:",
        examSubjects
    );

    console.log(
        "Master Students:",
        masterStudents.length
    );

    console.log(
        "Eligible Students:",
        examStudents.length
    );

    console.log(
        "Additional Entries:",
        additionalStudents.length
    );

    console.log(
        "Total Students for Seating:",
        students.length
    );

    console.log(
        "================================"
    );

}


/* ==========================================
   ROOM CAPACITY
========================================== */

function getRoomCapacity(
    room
) {

    const left =
        Number(
            room?.rowsLeft || 0
        );


    const right =
        Number(
            room?.rowsRight || 0
        );


    const perBench =
        Number(
            room?.studentsPerBench || 0
        );


    return (
        (left + right) *
        perBench
    );

}


/* ==========================================
   CREATE PHYSICAL SEATS
========================================== */

function createRoomSeats(
    room
) {

    const seats = [];


    const rowsLeft =
        Number(
            room?.rowsLeft || 0
        );


    const rowsRight =
        Number(
            room?.rowsRight || 0
        );


    const studentsPerBench =
        Number(
            room?.studentsPerBench || 0
        );


    /* ======================================
       COLUMN A
    ====================================== */

    for (
        let bench = 1;
        bench <= rowsLeft;
        bench++
    ) {

        /*
           First position
           A
        */

        if (
            studentsPerBench >= 1
        ) {

            seats.push({

                roomId:
                    room._id,

                roomNumber:
                    room.roomNumber,

                column:
                    "A",

                bench,

                seat:
                    "A"

            });

        }


        /*
           Middle position
           C
        */

        if (
            studentsPerBench >= 3
        ) {

            seats.push({

                roomId:
                    room._id,

                roomNumber:
                    room.roomNumber,

                column:
                    "A",

                bench,

                seat:
                    "C"

            });

        }


        /*
           Third position
           B
        */

        if (
            studentsPerBench >= 2
        ) {

            seats.push({

                roomId:
                    room._id,

                roomNumber:
                    room.roomNumber,

                column:
                    "A",

                bench,

                seat:
                    "B"

            });

        }

    }


    /* ======================================
       COLUMN B
    ====================================== */

    for (
        let bench = 1;
        bench <= rowsRight;
        bench++
    ) {

        if (
            studentsPerBench >= 1
        ) {

            seats.push({

                roomId:
                    room._id,

                roomNumber:
                    room.roomNumber,

                column:
                    "B",

                bench,

                seat:
                    "A"

            });

        }


        if (
            studentsPerBench >= 3
        ) {

            seats.push({

                roomId:
                    room._id,

                roomNumber:
                    room.roomNumber,

                column:
                    "B",

                bench,

                seat:
                    "C"

            });

        }


        if (
            studentsPerBench >= 2
        ) {

            seats.push({

                roomId:
                    room._id,

                roomNumber:
                    room.roomNumber,

                column:
                    "B",

                bench,

                seat:
                    "B"

            });

        }

    }


    return seats;

}


/* ==========================================
   GROUP STUDENTS BY DEPARTMENT
========================================== */

function groupStudentsByDepartment(
    studentList
) {

    const groups = {};


    studentList.forEach(
        student => {

            const department =
                normalizeDepartment(
                    student.department
                );


            const key =
                department ||
                "UNKNOWN";


            if (
                !groups[key]
            ) {

                groups[key] = [];

            }


            groups[key].push(
                student
            );

        }
    );


    return groups;

}

/* ==========================================
   SEATING RULE HELPERS
========================================== */

/*
   Returns the paper/subject assigned to
   a student for the selected examination.

   The examination stores subjects like:

   {
       subjectCode,
       subjectName,
       departments: []
   }

   Therefore the student's department tells
   us which paper the student is writing.
*/

function getStudentPaperKey(student) {

    const department =
        normalizeDepartment(
            student?.department
        );

    if (
        !selectedExam ||
        !Array.isArray(selectedExam.subjects)
    ) {
        return "";
    }

    const subject =
        selectedExam.subjects.find(subject => {

            if (
                !Array.isArray(
                    subject.departments
                )
            ) {
                return false;
            }

            return subject.departments.some(
                examDepartment => {

                    const normalized =
                        normalizeDepartment(
                            examDepartment
                        );

                    /*
                       BCOM.CA/CP in the examination
                       represents both master departments.
                    */

                    if (
                        normalized ===
                        "BCOM.CA/CP"
                    ) {

                        return (
                            department ===
                                "BCOM.CA" ||
                            department ===
                                "BCOM.CP"
                        );

                    }

                    return (
                        normalized ===
                        department
                    );

                }
            );

        });

    if (!subject) {
        return "";
    }

    /*
       Prefer subject code because it is the
       strongest identifier.

       If no code exists, use subject name.
    */

    return normalizeDepartment(
        subject.subjectCode ||
        subject.subjectName ||
        ""
    );

}


/* ==========================================
   CHECK BENCH COMPATIBILITY
========================================== */

function canSitTogether(
    firstStudent,
    secondStudent,
    currentBenchStudents = []
) {

    const studentsOnBench = [
        ...currentBenchStudents
    ];

    /*
       --------------------------------------
       RULE 1
       Different departments only
       --------------------------------------
    */

    const firstDepartment =
        normalizeDepartment(
            firstStudent?.department
        );

    const secondDepartment =
        normalizeDepartment(
            secondStudent?.department
        );

    if (
        firstDepartment &&
        secondDepartment &&
        firstDepartment ===
            secondDepartment
    ) {

        return false;

    }


    /*
       --------------------------------------
       RULE 2
       Same paper cannot share bench
       --------------------------------------
    */

    const firstPaper =
        getStudentPaperKey(
            firstStudent
        );

    const secondPaper =
        getStudentPaperKey(
            secondStudent
        );

    if (
        firstPaper &&
        secondPaper &&
        firstPaper === secondPaper
    ) {

        return false;

    }


    /*
       --------------------------------------
       Check against every student already
       placed on this bench.
       --------------------------------------
    */

    for (
        const existingStudent
        of studentsOnBench
    ) {

        const existingDepartment =
            normalizeDepartment(
                existingStudent?.department
            );

        const existingPaper =
            getStudentPaperKey(
                existingStudent
            );


        /*
           Same department
        */

        if (
            existingDepartment &&
            firstDepartment &&
            existingDepartment ===
                firstDepartment
        ) {

            return false;

        }


        /*
           Same paper
        */

        if (
            existingPaper &&
            firstPaper &&
            existingPaper ===
                firstPaper
        ) {

            return false;

        }

    }


    return true;

}


/* ==========================================
   CREATE VALID BENCH GROUP
========================================== */

function createBenchGroup(
    availableStudents,
    benchSize
) {

    if (
        !Array.isArray(
            availableStudents
        ) ||
        availableStudents.length === 0
    ) {

        return null;

    }


    /*
       Start with the student who has the
       highest number of remaining students
       from the same department.

       This helps prevent one department
       getting stranded near the end.
    */

    const departmentCounts = {};

    availableStudents.forEach(
        student => {

            const department =
                normalizeDepartment(
                    student?.department
                ) || "UNKNOWN";

            departmentCounts[department] =
                (
                    departmentCounts[
                        department
                    ] || 0
                ) + 1;

        }
    );


    const sortedStudents =
        [...availableStudents].sort(
            (a, b) => {

                const deptA =
                    normalizeDepartment(
                        a?.department
                    ) || "UNKNOWN";

                const deptB =
                    normalizeDepartment(
                        b?.department
                    ) || "UNKNOWN";

                return (
                    departmentCounts[deptB] -
                    departmentCounts[deptA]
                );

            }
        );


    /*
       Try each possible first student.

       This gives us a much better chance of
       finding a valid combination than simply
       taking students in database order.
    */

    for (
        const firstStudent
        of sortedStudents
    ) {

        const group = [
            firstStudent
        ];


        /*
           Candidates must be compatible with
           everybody already on the bench.
        */

        const candidates =
            availableStudents
                .filter(
                    student =>
                        student !==
                        firstStudent
                )
                .filter(
                    student =>
                        canSitTogether(
                            student,
                            firstStudent,
                            group
                        )
                );


        /*
           Prefer candidates whose department
           and paper are less represented in the
           remaining students.
        */

        candidates.sort(
            (a, b) => {

                const deptA =
                    normalizeDepartment(
                        a?.department
                    ) || "UNKNOWN";

                const deptB =
                    normalizeDepartment(
                        b?.department
                    ) || "UNKNOWN";

                return (
                    (
                        departmentCounts[
                            deptB
                        ] || 0
                    ) -
                    (
                        departmentCounts[
                            deptA
                        ] || 0
                    )
                );

            }
        );


        for (
            const candidate
            of candidates
        ) {

            if (
                canSitTogether(
                    candidate,
                    firstStudent,
                    group
                )
            ) {

                group.push(
                    candidate
                );

            }


            if (
                group.length >=
                benchSize
            ) {

                return group;

            }

        }

    }


    /*
       No valid group found.
    */

    return null;

}


/* ==========================================
   BUILD COMPLETE VALID SEATING
========================================== */

function createValidSeatingOrder(
    studentList,
    benchDefinitions
) {

    if (
        !Array.isArray(studentList) ||
        !Array.isArray(benchDefinitions)
    ) {

        return null;

    }


    let remainingStudents =
        [...studentList];

    const result = [];


    /*
       Process each physical bench.
    */

    for (
        const bench
        of benchDefinitions
    ) {

        if (
            remainingStudents.length === 0
        ) {

            break;

        }


        const benchSize =
            bench.seats.length;


        /*
           If fewer students remain than
           the physical bench size, we can
           use the remaining students only if
           the room physically permits it.
        */

        const actualBenchSize =
            Math.min(
                benchSize,
                remainingStudents.length
            );


        const group =
            createBenchGroup(
                remainingStudents,
                actualBenchSize
            );


        if (!group) {

            return {
                success: false,

                reason:
                    `Unable to create a valid bench in Room ${bench.roomNumber}, Column ${bench.column}, Bench ${bench.bench}.`
            };

        }


        /*
           Add students to the result in the
           exact physical seat order.
        */

        group.forEach(
            (student, index) => {

                const physicalSeat =
                    bench.seats[index];

                result.push({

                    student,

                    physicalSeat

                });

            }
        );


        /*
           Remove allocated students.
        */

        const allocatedRegisters =
            new Set(
                group.map(
                    student =>
                        getRegisterNumber(
                            student
                        )
                )
            );


        remainingStudents =
            remainingStudents.filter(
                student =>
                    !allocatedRegisters.has(
                        getRegisterNumber(
                            student
                        )
                    )
            );

    }


    /*
       If anybody remains, capacity/rules
       could not accommodate them.
    */

    if (
        remainingStudents.length > 0
    ) {

        return {

            success: false,

            reason:
                `${remainingStudents.length} students could not be seated while maintaining the seating rules.`

        };

    }


    return {

        success: true,

        allocations: result

    };

}

/* ==========================================
   GET STUDENT PAPER
========================================== */

function getStudentPaperKey(student) {

    if (!selectedExam) {

        return "UNKNOWN_PAPER";

    }


    const studentDepartment =
        normalizeDepartment(
            student.department
        );


    const subjects =
        Array.isArray(
            selectedExam.subjects
        )
            ? selectedExam.subjects
            : [];


    /*
       Find the subject belonging to
       this student's department.
    */
    const matchingSubject =
        subjects.find(subject => {

            const departments =
                Array.isArray(
                    subject.departments
                )
                    ? subject.departments
                    : [];


            return departments.some(
                department => {

                    return (
                        normalizeDepartment(
                            department
                        ) ===
                        studentDepartment
                    );

                }
            );

        });


    if (!matchingSubject) {

        return "UNKNOWN_PAPER";

    }


    /*
       Prefer subject code because it is
       the strongest paper identifier.
    */
    if (
        matchingSubject.subjectCode &&
        String(
            matchingSubject.subjectCode
        ).trim()
    ) {

        return String(
            matchingSubject.subjectCode
        )
            .trim()
            .toUpperCase();

    }


    if (
        matchingSubject.subjectName &&
        String(
            matchingSubject.subjectName
        ).trim()
    ) {

        return String(
            matchingSubject.subjectName
        )
            .trim()
            .toUpperCase();

    }


    return "UNKNOWN_PAPER";

}

/* ==========================================
   CHECK IF STUDENTS CAN SHARE A BENCH
========================================== */

function canShareBench(
    existingStudents,
    candidate
) {

    if (
        !Array.isArray(
            existingStudents
        )
    ) {

        return true;

    }


    const candidateDepartment =
        normalizeDepartment(
            candidate.department
        );


    const candidatePaper =
        getStudentPaperKey(
            candidate
        );


    for (
        const existingStudent
        of existingStudents
    ) {

        const existingDepartment =
            normalizeDepartment(
                existingStudent.department
            );


        const existingPaper =
            getStudentPaperKey(
                existingStudent
            );


        /*
           RULE 1:
           Same department is NOT allowed.
        */
        if (
            existingDepartment ===
            candidateDepartment
        ) {

            return false;

        }


        /*
           RULE 2:
           Same paper is NOT allowed.
        */
        if (
            candidatePaper !==
            "UNKNOWN_PAPER" &&
            existingPaper !==
            "UNKNOWN_PAPER" &&
            candidatePaper ===
            existingPaper
        ) {

            return false;

        }

    }


    return true;

}

/* ==========================================
   GENERATION PROGRESS
========================================== */

function showGenerationProgress() {

    if (
        typeof Swal === "undefined"
    ) {

        return;

    }


    Swal.fire({

        title:
            "Generating Seating Arrangement",

        html: `

            <div
                style="
                    text-align:center;
                    padding:10px;
                "
            >

                <div
                    id="seatingProgressText"
                    style="
                        font-size:16px;
                        font-weight:600;
                        margin-bottom:15px;
                    "
                >
                    Preparing students...
                </div>


                <div
                    style="
                        width:100%;
                        height:10px;
                        background:#e5e7eb;
                        border-radius:10px;
                        overflow:hidden;
                    "
                >

                    <div
                        id="seatingProgressBar"
                        style="
                            width:0%;
                            height:100%;
                            background:#1687f8;
                            transition:width .4s ease;
                        "
                    ></div>

                </div>


                <div
                    id="seatingProgressPercent"
                    style="
                        margin-top:10px;
                        font-size:14px;
                    "
                >
                    0%
                </div>

            </div>

        `,

        allowOutsideClick:
            false,

        allowEscapeKey:
            false,

        showConfirmButton:
            false

    });

}


/* ==========================================
   UPDATE PROGRESS
========================================== */

function updateGenerationProgress(
    percent,
    message
) {

    const bar =
        document.getElementById(
            "seatingProgressBar"
        );


    const text =
        document.getElementById(
            "seatingProgressText"
        );


    const percentage =
        document.getElementById(
            "seatingProgressPercent"
        );


    if (bar) {

        bar.style.width =
            `${percent}%`;

    }


    if (text) {

        text.textContent =
            message;

    }


    if (percentage) {

        percentage.textContent =
            `${percent}%`;

    }

}


/* ==========================================
   DELAY
========================================== */

function wait(
    milliseconds
) {

    return new Promise(
        resolve =>
            setTimeout(
                resolve,
                milliseconds
            )
    );

}

async function saveSeatingToDatabase() {
    if (!selectedExam || !selectedExam._id) {
        console.error("❌ No selected exam found.");
        return false;
    }

    if (!Array.isArray(seating)) {
        console.error("❌ Seating data is invalid.");
        return false;
    }

    const token = localStorage.getItem("token");

    if (!token) {
        console.error("❌ Teacher authentication token not found.");
        return false;
    }

    try {
        const response = await fetch(`${SEATING_API}/save`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({
                examId: selectedExam._id,
                seating: seating
            })
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("❌ Failed to save seating:", data);
            return false;
        }

        console.log("✅ Seating saved to MongoDB.");

        return true;

    } catch (error) {
        console.error("❌ Seating database error:", error);
        return false;
    }
}

/* ==========================================
   GENERATE SEATING
========================================== */

async function generateSeating() {

    /* --------------------------------------
       VALIDATION
    -------------------------------------- */

    if (!selectedExam) {

        await showAlert(
            "Select Examination",
            "Please select an examination first.",
            "warning"
        );

        return;

    }


    if (!students.length) {

        await showAlert(
            "No Students",
            "No students are available for this examination.",
            "warning"
        );

        return;

    }


    if (!rooms.length) {

        await showAlert(
            "No Rooms",
            "No examination rooms are configured.",
            "warning"
        );

        return;

    }


    /* --------------------------------------
       OPEN PROGRESS
    -------------------------------------- */

    showGenerationProgress();


    /* --------------------------------------
       STEP 1
    -------------------------------------- */

    updateGenerationProgress(
        10,
        `Preparing ${students.length} students...`
    );

    await wait(400);


    /* --------------------------------------
       STEP 2
    -------------------------------------- */

    updateGenerationProgress(
        25,
        `Checking ${rooms.length} examination rooms...`
    );

    await wait(400);


    /* --------------------------------------
       STEP 3
    -------------------------------------- */

    updateGenerationProgress(
        40,
        "Creating physical seating positions..."
    );


    const allSeats = [];


    rooms.forEach(
        room => {

            const roomSeats =
                createRoomSeats(
                    room
                );


            allSeats.push(
                ...roomSeats
            );

        }
    );


    await wait(500);


    /* --------------------------------------
       CAPACITY CHECK
    -------------------------------------- */

    if (
        students.length >
        allSeats.length
    ) {

        Swal.close();


        await showAlert(
            "Insufficient Capacity",
            `${students.length} students require seats, but only ${allSeats.length} physical seats are available.`,
            "error"
        );

        return;

    }


    /* --------------------------------------
       STEP 4
    -------------------------------------- */

    updateGenerationProgress(
        55,
        "Arranging students by department..."
    );


    const orderedStudents =
        createMixedStudentOrder(
            [...students]
        );


    await wait(500);


    /* --------------------------------------
   STEP 5
-------------------------------------- */

updateGenerationProgress(
    70,
    "Assigning students using seating rules..."
);


seating = [];


/*
   Create physical bench groups.

   Every physical bench is treated as
   one seating unit.

   Example:

   Room 1 / Column A / Bench 1
   Room 1 / Column A / Bench 2
   Room 1 / Column B / Bench 1
   ...
*/

const benches = [];


rooms.forEach(room => {

    const rowsLeft =
        Number(
            room?.rowsLeft || 0
        );

    const rowsRight =
        Number(
            room?.rowsRight || 0
        );


    const studentsPerBench =
        Number(
            room?.studentsPerBench || 0
        );


    /*
       Column A benches
    */
    for (
        let bench = 1;
        bench <= rowsLeft;
        bench++
    ) {

        benches.push({

            roomId:
                room._id,

            roomNumber:
                room.roomNumber,

            column:
                "A",

            bench,

            capacity:
                studentsPerBench

        });

    }


    /*
       Column B benches
    */
    for (
        let bench = 1;
        bench <= rowsRight;
        bench++
    ) {

        benches.push({

            roomId:
                room._id,

            roomNumber:
                room.roomNumber,

            column:
                "B",

            bench,

            capacity:
                studentsPerBench

        });

    }

});


/*
   Try several randomized arrangements.

   This gives the generator multiple chances
   to find a valid arrangement instead of
   depending on one lucky ordering.
*/

let successfulAllocation = null;

const MAX_ATTEMPTS = 100;


for (
    let attempt = 1;
    attempt <= MAX_ATTEMPTS;
    attempt++
) {

    /*
       Shuffle students for this attempt.
    */
    const shuffledStudents =
        createMixedStudentOrder(
            [...students]
        );


    const benchStudents =
        benches.map(
            bench => ({
                ...bench,
                students: []
            })
        );


    let failed = false;


    /*
       Place every student into a bench
       where the seating rules are satisfied.
    */
    for (
        const student
        of shuffledStudents
    ) {

        let placed = false;


        /*
           Find the best available bench.

           Prefer benches that currently have
           fewer students.
        */
        const availableBenches =
            benchStudents
                .filter(
                    bench =>
                        bench.students.length <
                        bench.capacity
                )
                .sort(
                    (a, b) =>
                        a.students.length -
                        b.students.length
                );


        /*
           Randomize benches having the
           same current size.
        */
        for (
            let i =
                availableBenches.length - 1;
            i > 0;
            i--
        ) {

            const j =
                Math.floor(
                    Math.random() *
                    (i + 1)
                );


            [
                availableBenches[i],
                availableBenches[j]
            ] = [
                availableBenches[j],
                availableBenches[i]
            ];

        }


        for (
            const bench
            of availableBenches
        ) {

            if (
                canShareBench(
                    bench.students,
                    student
                )
            ) {

                bench.students.push(
                    student
                );

                placed = true;

                break;

            }

        }


        /*
           If this student cannot fit into
           any valid bench, this attempt failed.
        */
        if (!placed) {

            failed = true;

            break;

        }

    }


    if (failed) {

        continue;

    }


    /*
       Convert bench groups into the
       physical A / C / B seats.
    */
    const generatedSeating = [];


    for (
        const bench
        of benchStudents
    ) {

        const seatsForBench = [
            "A"
        ];


        if (
            bench.capacity >= 3
        ) {

            seatsForBench.push(
                "C"
            );

        }


        if (
            bench.capacity >= 2
        ) {

            seatsForBench.push(
                "B"
            );

        }


        bench.students.forEach(
            (
                student,
                index
            ) => {

                const seat =
                    seatsForBench[index];


                if (!seat) {

                    return;

                }


                generatedSeating.push({

                    registerNumber:
                        getRegisterNumber(
                            student
                        ),

                    name:
                        student.name || "",

                    department:
                        student.department || "",

                    semester:
                        student.semester || "",

                    roomId:
                        bench.roomId,

                    roomNumber:
                        bench.roomNumber,

                    bench:
                        bench.bench,

                    column:
                        bench.column,

                    seat

                });

            }
        );

    }


    /*
       Final count check.
    */
    if (
        generatedSeating.length ===
        students.length
    ) {

        successfulAllocation =
            generatedSeating;

        break;

    }

}


/*
   No valid arrangement found.
*/
if (
    !successfulAllocation
) {

    Swal.close();


    await showAlert(
        "Seating Rules Could Not Be Satisfied",
        "SmartSeat could not find a valid arrangement with the configured rooms and seating rules. Please check room capacity and student distribution.",
        "error"
    );


    seating = [];

    updateStatistics();

    renderSeatingTable();

    return;

}


/*
   Use the successful arrangement.
*/
seating =
    successfulAllocation;


await wait(500);


    await wait(500);


    /* --------------------------------------
       STEP 6
    -------------------------------------- */

    updateGenerationProgress(
        85,
        "Verifying student allocation..."
    );


    await wait(500);


    /* --------------------------------------
       VERIFY COUNT
    -------------------------------------- */

    const allocated =
        seating.length;


    const physicalCapacity =
        allSeats.length;


    const remaining =
        physicalCapacity -
        allocated;


    /* --------------------------------------
       VERIFY DUPLICATES
    -------------------------------------- */

    const registerNumbers =
        seating.map(
            item =>
                item.registerNumber
        );


    const uniqueRegisterNumbers =
        new Set(
            registerNumbers
        );


    if (
        uniqueRegisterNumbers.size !==
        seating.length
    ) {

        Swal.close();


        seating = [];


        updateStatistics();
        renderSeatingTable();
        saveGeneratedReportData();

        await showAlert(
            "Allocation Error",
            "Duplicate register numbers were detected. Seating generation was stopped.",
            "error"
        );

        return;

    }


    /* --------------------------------------
       VERIFY ALLOCATION COUNT
    -------------------------------------- */

    if (
        allocated !==
        students.length
    ) {

        Swal.close();


        seating = [];


        updateStatistics();

        renderSeatingTable();


        await showAlert(
            "Allocation Error",
            `Only ${allocated} of ${students.length} students were allocated.`,
            "error"
        );

        return;

    }


    /* --------------------------------------
       FINAL PROGRESS
    -------------------------------------- */

    updateGenerationProgress(
        100,
        "Seating arrangement completed!"
    );


    await wait(700);


    Swal.close();


    updateStatistics();

    renderSeatingTable();

/* --------------------------------------
   SAVE REPORT DATA
-------------------------------------- */

    saveGeneratedReportData();

// Save seating to MongoDB
    await saveSeatingToDatabase();

/* --------------------------------------
   SUCCESS POPUP
-------------------------------------- */

    const result =
        await Swal.fire({

            icon:
                "success",

            title:
                "Seating Generated Successfully",

            html: `

                <div
                    style="
                        font-size:16px;
                        line-height:1.8;
                    "
                >

                    <strong>
                        ${allocated}
                    </strong>

                    students allocated successfully.

                    <br>

                    <strong>
                        ${remaining}
                    </strong>

                    physical seats remaining.

                </div>

            `,

            confirmButtonText:
                "View Seating"

        });


    if (
        result.isConfirmed
    ) {

        document
            .querySelector(
                ".table-card"
            )
            ?.scrollIntoView({
                behavior:
                    "smooth"
            });

    }


    /* --------------------------------------
       DEBUG
    -------------------------------------- */

    console.log(
        "================================"
    );

    console.log(
        "✅ SEATING GENERATED"
    );

    console.log(
        "Students:",
        students.length
    );

    console.log(
        "Physical Seats:",
        physicalCapacity
    );

    console.log(
        "Allocated:",
        allocated
    );

    console.log(
        "Remaining:",
        remaining
    );

    console.log(
        "================================"
    );


    console.table(
        seating.slice(
            0,
            20
        )
    );

}


/* ==========================================
   RENDER SEATING TABLE
========================================== */

function renderSeatingTable() {

    const tableBody =
        document.getElementById(
            "seatingTable"
        );


    if (!tableBody) {

        console.error(
            "❌ #seatingTable not found."
        );

        return;

    }


    /* --------------------------------------
       EMPTY
    -------------------------------------- */

    if (!seating.length) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="9"
                    class="text-center"
                >

                    No Seating Generated

                </td>

            </tr>

        `;


        updateDepartmentFilter();

        updateVerificationSummary(
            0
        );

        return;

    }


    /* --------------------------------------
       FILTER DROPDOWN
    -------------------------------------- */

    updateDepartmentFilter();


    /* --------------------------------------
       SEARCH
    -------------------------------------- */

    const searchInput =
        document.getElementById(
            "seatingSearch"
        );


    const departmentSelect =
        document.getElementById(
            "departmentFilter"
        );


    const search =
        (
            searchInput?.value ||
            ""
        )
            .trim()
            .toLowerCase();


    const department =
        (
            departmentSelect?.value ||
            ""
        )
            .trim()
            .toUpperCase();


    /* --------------------------------------
       FILTER
    -------------------------------------- */

    const filtered =
        seating.filter(
            allocation => {

                const registerNumber =
                    String(
                        allocation.registerNumber ||
                        ""
                    )
                        .toLowerCase();


                const name =
                    String(
                        allocation.name ||
                        ""
                    )
                        .toLowerCase();


                const studentDepartment =
                    normalizeDepartment(
                        allocation.department
                    );


                const matchesSearch =
                    !search ||
                    registerNumber.includes(
                        search
                    ) ||
                    name.includes(
                        search
                    );


                const matchesDepartment =
                    !department ||
                    studentDepartment ===
                    department;


                return (
                    matchesSearch &&
                    matchesDepartment
                );

            }
        );


    /* --------------------------------------
       NO FILTER RESULT
    -------------------------------------- */

    if (!filtered.length) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="9"
                    class="text-center"
                >

                    No students found.

                </td>

            </tr>

        `;


        updateVerificationSummary(
            0
        );

        return;

    }


    /* --------------------------------------
       RENDER
    -------------------------------------- */

    tableBody.innerHTML = "";


    filtered.forEach(
        (
            allocation,
            index
        ) => {

            const row =
                document.createElement(
                    "tr"
                );


            row.innerHTML = `

                <td>
                    ${index + 1}
                </td>

                <td>
                    ${escapeHtml(
                        allocation.registerNumber
                    )}
                </td>

                <td>
                    ${escapeHtml(
                        allocation.name
                    )}
                </td>

                <td>
                    ${escapeHtml(
                        allocation.department
                    )}
                </td>

                <td>
                    ${escapeHtml(
                        allocation.semester
                    )}
                </td>

                <td>
                    ${escapeHtml(
                        allocation.roomNumber
                    )}
                </td>

                <td>
                    ${allocation.bench}
                </td>

                <td>
                    ${escapeHtml(
                        allocation.column
                    )}
                </td>

                <td>
                    <strong>
                        ${escapeHtml(
                            allocation.seat
                        )}
                    </strong>
                </td>

            `;


            tableBody.appendChild(
                row
            );

        }
    );


    /* --------------------------------------
       VERIFICATION
    -------------------------------------- */

    updateVerificationSummary(
        filtered.length
    );

}


/* ==========================================
   DEPARTMENT FILTER
========================================== */

function updateDepartmentFilter() {

    const select =
        document.getElementById(
            "departmentFilter"
        );


    if (!select) {

        return;

    }


    const currentValue =
        select.value;


    const departments =
        [
            ...new Set(
                seating
                    .map(
                        student =>
                            normalizeDepartment(
                                student.department
                            )
                    )
                    .filter(Boolean)
            )
        ]
            .sort();


    select.innerHTML = `

        <option value="">
            All Departments
        </option>

    `;


    departments.forEach(
        department => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                department;


            option.textContent =
                department;


            select.appendChild(
                option
            );

        }
    );


    if (
        departments.includes(
            currentValue
        )
    ) {

        select.value =
            currentValue;

    }

}


/* ==========================================
   VERIFICATION SUMMARY
========================================== */

function updateVerificationSummary(
    filteredCount = seating.length
) {

    const verification =
        document.getElementById(
            "seatingVerification"
        );


    if (!verification) {

        return;

    }


    if (!seating.length) {

        verification.innerHTML = `

            <div
                class="alert alert-secondary mb-0"
            >

                <strong>
                    Seating not generated yet.
                </strong>

            </div>

        `;

        return;

    }


    const expected =
        students.length;


    const allocated =
        seating.length;


    const registerNumbers =
        seating.map(
            student =>
                getRegisterNumber(
                    student
                )
        );


    const uniqueRegisters =
        new Set(
            registerNumbers
        );


    const duplicates =
        registerNumbers.length -
        uniqueRegisters.size;


    const missingSeatData =
        seating.filter(
            student =>

                !student.roomNumber ||
                !student.bench ||
                !student.column ||
                !student.seat

        ).length;


    const allocationCorrect =
        allocated ===
        expected;


    const duplicateCorrect =
        duplicates === 0;


    const seatDataCorrect =
        missingSeatData === 0;


    const allCorrect =
        allocationCorrect &&
        duplicateCorrect &&
        seatDataCorrect;


    verification.innerHTML = `

        <div
            class="alert ${
                allCorrect
                    ? "alert-success"
                    : "alert-danger"
            } mb-0"
        >

            <div
                class="d-flex flex-wrap gap-4"
            >

                <div>

                    <strong>
                        Students:
                    </strong>

                    ${expected}

                </div>


                <div>

                    <strong>
                        Allocated:
                    </strong>

                    ${allocated}

                </div>


                <div>

                    <strong>
                        Showing:
                    </strong>

                    ${filteredCount}

                </div>


                <div>

                    <strong>
                        Unique:
                    </strong>

                    ${uniqueRegisters.size}

                </div>


                <div>

                    <strong>
                        Duplicate:
                    </strong>

                    ${duplicates}

                </div>


                <div>

                    <strong>
                        Missing Seat Data:
                    </strong>

                    ${missingSeatData}

                </div>

            </div>


            <hr>


            <strong>

                ${
                    allCorrect

                        ? "✅ Verification Passed — All students are allocated correctly."

                        : "⚠️ Verification requires attention."

                }

            </strong>

        </div>

    `;

}


/* ==========================================
   SEARCH + FILTER EVENTS
========================================== */

function setupSeatingFilters() {

    const searchInput =
        document.getElementById(
            "seatingSearch"
        );


    const departmentSelect =
        document.getElementById(
            "departmentFilter"
        );


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            renderSeatingTable
        );

    }


    if (departmentSelect) {

        departmentSelect.addEventListener(
            "change",
            renderSeatingTable
        );

    }

}


/* ==========================================
   HTML ESCAPE
========================================== */

function escapeHtml(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


/* ==========================================
   STATISTICS
========================================== */

function updateStatistics() {

    let capacity = 0;


    rooms.forEach(
        room => {

            capacity +=
                getRoomCapacity(
                    room
                );

        }
    );


    const studentCount =
        document.getElementById(
            "studentCount"
        );


    const roomCount =
        document.getElementById(
            "roomCount"
        );


    const capacityCount =
        document.getElementById(
            "capacityCount"
        );


    const allocatedCount =
        document.getElementById(
            "allocatedCount"
        );


    const remainingCount =
        document.getElementById(
            "remainingCount"
        );


    if (studentCount) {

        studentCount.textContent =
            students.length;

    }


    if (roomCount) {

        roomCount.textContent =
            rooms.length;

    }


    if (capacityCount) {

        capacityCount.textContent =
            capacity;

    }


    if (allocatedCount) {

        allocatedCount.textContent =
            seating.length;

    }


    if (remainingCount) {

        remainingCount.textContent =
            Math.max(
                0,
                capacity -
                seating.length
            );

    }

}


/* ==========================================
   ADDITIONAL STATUS
========================================== */

function updateAdditionalStatus() {

    const status =
        document.getElementById(
            "rollStatus"
        );


    if (!status) return;


    if (!selectedExamId) {

        status.textContent =
            "No Additional Entries";

        return;

    }


    const additionalStudents =
        getAdditionalStudents(
            selectedExamId
        );


    if (
        additionalStudents.length >
        0
    ) {

        status.textContent =
            `${additionalStudents.length} Additional ${
                additionalStudents.length === 1
                    ? "Entry"
                    : "Entries"
            }`;

    }

    else {

        status.textContent =
            "No Additional Entries";

    }

}


/* ==========================================
   CLEAR SEATING
========================================== */

async function clearGeneratedSeating() {

    if (!seating.length) {

        await showAlert(
            "Nothing to Clear",
            "No seating arrangement has been generated yet.",
            "info"
        );

        return;

    }


    const result =
        await Swal.fire({

            title:
                "Clear Seating Arrangement?",

            text:
                "The generated seating arrangement will be cleared.",

            icon:
                "warning",

            showCancelButton:
                true,

            confirmButtonText:
                "Yes, Clear",

            cancelButtonText:
                "Cancel"

        });


    if (
        !result.isConfirmed
    ) {

        return;

    }


    seating = [];

localStorage.removeItem(
    "smartseatGeneratedReport"
);

updateStatistics();

renderSeatingTable();


    await Swal.fire({

        icon:
            "success",

        title:
            "Seating Cleared",

        text:
            "The generated seating arrangement has been cleared."

    });

}


/* ==========================================
   MANUAL ENTRY
========================================== */

function openManualEntry() {

    if (!selectedExam) {

        showAlert(
            "Select Examination",
            "Please select an examination first.",
            "warning"
        );

        return;

    }


    const modalElement =
        document.getElementById(
            "manualModal"
        );


    if (!modalElement) {

        showAlert(
            "Manual Entry Unavailable",
            "The manual entry window could not be found.",
            "error"
        );

        return;

    }


    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );


    modal.show();

}


/* ==========================================
   MANUAL ALLOCATION
========================================== */

async function allocateManualStudent() {

    const registerNumber =
        document.getElementById(
            "manualRegNo"
        )?.value
            .trim();


    const name =
        document.getElementById(
            "manualName"
        )?.value
            .trim();


    const semester =
        document.getElementById(
            "manualSemester"
        )?.value;


    if (!selectedExam) {

        showAlert(
            "Select Examination",
            "Please select an examination first.",
            "warning"
        );

        return;

    }


    if (
        !registerNumber ||
        !name ||
        !semester
    ) {

        showAlert(
            "Incomplete Details",
            "Please enter register number, student name and semester.",
            "warning"
        );

        return;

    }


    /* --------------------------------------
       DUPLICATE CHECK
    -------------------------------------- */

    const duplicate =
        seating.some(
            item =>
                getRegisterNumber(
                    item
                ) ===
                registerNumber
                    .toUpperCase()
        );


    if (duplicate) {

        showAlert(
            "Student Already Allocated",
            "This register number already has a seat.",
            "warning"
        );

        return;

    }


    /* --------------------------------------
       CREATE ALL PHYSICAL SEATS
    -------------------------------------- */

    const allSeats = [];


    rooms.forEach(
        room => {

            allSeats.push(
                ...createRoomSeats(
                    room
                )
            );

        }
    );


    /* --------------------------------------
       USED SEATS
    -------------------------------------- */

    const usedSeats =
        new Set(
            seating.map(
                item =>
                    `${item.roomId}|${item.column}|${item.bench}|${item.seat}`
            )
        );


    /* --------------------------------------
       FIRST FREE SEAT
    -------------------------------------- */

    const freeSeat =
        allSeats.find(
            seat =>
                !usedSeats.has(
                    `${seat.roomId}|${seat.column}|${seat.bench}|${seat.seat}`
                )
        );


    if (!freeSeat) {

        showAlert(
            "No Available Seat",
            "All physical seats are already occupied.",
            "error"
        );

        return;

    }


    /* --------------------------------------
       ADD STUDENT
    -------------------------------------- */

    seating.push({

        registerNumber:
            registerNumber.toUpperCase(),

        name,

        department:
            "Manual Entry",

        semester,

        roomId:
            freeSeat.roomId,

        roomNumber:
            freeSeat.roomNumber,

        bench:
            freeSeat.bench,

        column:
            freeSeat.column,

        seat:
            freeSeat.seat

    });


    updateStatistics();

    renderSeatingTable();

    saveGeneratedReportData();


    /* --------------------------------------
       CLOSE MODAL
    -------------------------------------- */

    const modalElement =
        document.getElementById(
            "manualModal"
        );


    if (modalElement) {

        bootstrap.Modal
            .getOrCreateInstance(
                modalElement
            )
            .hide();

    }


    /* --------------------------------------
       CLEAR FORM
    -------------------------------------- */

    const regInput =
        document.getElementById(
            "manualRegNo"
        );


    const nameInput =
        document.getElementById(
            "manualName"
        );


    const semesterInput =
        document.getElementById(
            "manualSemester"
        );


    if (regInput) {

        regInput.value = "";

    }


    if (nameInput) {

        nameInput.value = "";

    }


    if (semesterInput) {

        semesterInput.value = "";

    }


    showAlert(
        "Student Allocated",
        `${registerNumber} has been assigned a seat.`,
        "success"
    );

}


/* ==========================================
   PREVIEW
========================================== */

async function previewSeating() {

    if (!selectedExam) {

        await showAlert(
            "Select Examination",
            "Please select an examination first.",
            "warning"
        );

        return;

    }


    /*
       If seating doesn't exist,
       Preview generates it.
    */

    if (!seating.length) {

        await generateSeating();

        return;

    }


    renderSeatingTable();


    document
        .querySelector(
            ".table-card"
        )
        ?.scrollIntoView({
            behavior:
                "smooth"
        });


    await Swal.fire({

        icon:
            "info",

        title:
            "Seating Preview",

        text:
            `${seating.length} students are currently allocated.`,

        confirmButtonText:
            "View Seating"

    });


    document
        .querySelector(
            ".table-card"
        )
        ?.scrollIntoView({
            behavior:
                "smooth"
        });

}


/* ==========================================
   EXPORT EXCEL
========================================== */

function exportExcel() {

    if (!seating.length) {

        showAlert(
            "No Seating",
            "Generate seating before exporting Excel.",
            "warning"
        );

        return;

    }


    if (
        typeof XLSX === "undefined"
    ) {

        showAlert(
            "Excel Library Missing",
            "The Excel export library could not be loaded.",
            "error"
        );

        return;

    }


    const exportData =
        seating.map(
            (
                item,
                index
            ) => ({

                "SL.NO":
                    index + 1,

                "Register No":
                    item.registerNumber,

                "Name":
                    item.name,

                "Department":
                    item.department,

                "Semester":
                    item.semester,

                "Room":
                    item.roomNumber,

                "Bench":
                    item.bench,

                "Column":
                    item.column,

                "Seat":
                    item.seat

            })
        );


    const worksheet =
        XLSX.utils.json_to_sheet(
            exportData
        );


    const workbook =
        XLSX.utils.book_new();


    XLSX.utils.book_append_sheet(
        workbook,
        worksheet,
        "Seating"
    );


    const examName =
        selectedExam?.examName ||
        "SmartSeat";


    XLSX.writeFile(
        workbook,
        `${examName.replace(
            /[^a-z0-9]/gi,
            "_"
        )}_Seating.xlsx`
    );


    showAlert(
        "Excel Exported",
        "The seating arrangement has been exported successfully.",
        "success"
    );

}


/* ==========================================
   OFFICIAL PDF
========================================== */

function generateOfficialPDF() {

    if (!seating.length) {

        showAlert(
            "No Seating",
            "Generate seating before creating the PDF.",
            "warning"
        );

        return;

    }


    const examName =
        selectedExam?.examName ||
        "Examination";


    const examDate =
        selectedExam?.examDate
            ? new Date(
                selectedExam.examDate
            ).toLocaleDateString(
                "en-IN"
            )
            : "";


    const printWindow =
        window.open(
            "",
            "_blank"
        );


    if (!printWindow) {

        showAlert(
            "Popup Blocked",
            "Please allow popups to generate the PDF.",
            "warning"
        );

        return;

    }


    let rows = "";


    seating.forEach(
        (
            item,
            index
        ) => {

            rows += `

                <tr>

                    <td>
                        ${index + 1}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.registerNumber
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.name
                        )}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.department
                        )}
                    </td>

                    <td>
                        ${item.semester}
                    </td>

                    <td>
                        ${escapeHtml(
                            item.roomNumber
                        )}
                    </td>

                    <td>
                        ${item.bench}
                    </td>

                    <td>
                        ${item.column}
                    </td>

                    <td>
                        ${item.seat}
                    </td>

                </tr>

            `;

        }
    );


    printWindow.document.write(`

        <!DOCTYPE html>

        <html>

        <head>

            <title>
                ${escapeHtml(
                    examName
                )}
                - Seating Arrangement
            </title>


           .print-btn {
    display: inline-block;
    padding: 10px 18px;
    margin-bottom: 20px;
    border: none;
    border-radius: 6px;
    background: #333;
    color: white;
    font-size: 14px;
    cursor: pointer;
}

@media print {
    .print-btn {
        display: none !important;
    }
}

        </head>


        <body>
        <button onclick="window.print()" class="print-btn">
    🖨️ Print / Save as PDF
</button>

            <h1>
                SMARTSEAT
            </h1>


            <h2>
                ${escapeHtml(
                    examName
                )}
            </h2>


            <p>
                ${
                    examDate
                        ? "Date: " +
                          escapeHtml(
                              examDate
                          )
                        : ""
                }
            </p>


            <table>

                <thead>

                    <tr>

                        <th>SL.NO</th>

                        <th>Register No</th>

                        <th>Name</th>

                        <th>Department</th>

                        <th>Semester</th>

                        <th>Room</th>

                        <th>Bench</th>

                        <th>Column</th>

                        <th>Seat</th>

                    </tr>

                </thead>


                <tbody>

                    ${rows}

                </tbody>

            </table>


            <br>


            <button
                onclick="
                    window.print()
                "
            >

                Print / Save as PDF

            </button>


        </body>

        </html>

    `);


    printWindow.document.close();

}

/* ==========================================
   SAVE GENERATED REPORT DATA
========================================== */

function saveGeneratedReportData() {

    try {

        const reportData = {

            examId:
                selectedExam?._id || "",

            exam:
                selectedExam || null,

            seating:
                Array.isArray(seating)
                    ? seating
                    : [],

            generatedAt:
                new Date().toISOString()

        };


        localStorage.setItem(
            "smartseatGeneratedReport",
            JSON.stringify(reportData)
        );


        console.log(
            "✅ Generated seating saved for Reports:",
            reportData.seating.length,
            "students"
        );


    }
    catch (error) {

        console.error(
            "❌ Failed to save report data:",
            error
        );

    }

}
/* ==========================================
   BUTTON EVENTS
========================================== */

function setupButtonEvents() {

    /* --------------------------------------
       GENERATE
    -------------------------------------- */

    const generateBtn =
        document.getElementById(
            "generateBtn"
        );


    if (generateBtn) {

        generateBtn.addEventListener(
            "click",
            generateSeating
        );

    }


    /* --------------------------------------
       PREVIEW
    -------------------------------------- */

    const previewBtn =
        document.getElementById(
            "previewBtn"
        );


    if (previewBtn) {

        previewBtn.addEventListener(
            "click",
            previewSeating
        );

    }


    /* --------------------------------------
       CLEAR
    -------------------------------------- */

    const clearBtn =
        document.getElementById(
            "clearBtn"
        );


    if (clearBtn) {

        clearBtn.addEventListener(
            "click",
            clearGeneratedSeating
        );

    }


    /* --------------------------------------
       MANUAL ENTRY
    -------------------------------------- */

    const manualBtn =
        document.getElementById(
            "manualBtn"
        );


    if (manualBtn) {

        manualBtn.addEventListener(
            "click",
            openManualEntry
        );

    }


    /* --------------------------------------
       MANUAL ALLOCATE
    -------------------------------------- */

    const allocateBtn =
        document.getElementById(
            "allocateBtn"
        );


    if (allocateBtn) {

        allocateBtn.addEventListener(
            "click",
            allocateManualStudent
        );

    }


    /* --------------------------------------
       PDF
    -------------------------------------- */

    const pdfBtn =
        document.getElementById(
            "pdfBtn"
        );


    if (pdfBtn) {

        pdfBtn.addEventListener(
            "click",
            generateOfficialPDF
        );

    }


    /* --------------------------------------
       EXCEL
    -------------------------------------- */

    const excelBtn =
        document.getElementById(
            "excelBtn"
        );


    if (excelBtn) {

        excelBtn.addEventListener(
            "click",
            exportExcel
        );

    }

}


/* ==========================================
   PAGE INITIALIZATION
========================================== */

document.addEventListener(
    "DOMContentLoaded",
    async () => {

        console.log(
            "📋 Initializing Seating Generator..."
        );


        /* --------------------------------------
           GET EXAM SELECT
        -------------------------------------- */

        examSelect =
            document.getElementById(
                "examSelect"
            );


        if (!examSelect) {

            console.error(
                "❌ #examSelect not found."
            );

            return;

        }


        /* --------------------------------------
           LOAD DATA
        -------------------------------------- */

        await loadExams();

        await loadRooms();

        await loadMasterStudents();


        /* --------------------------------------
           EXAM CHANGE
        -------------------------------------- */

        examSelect.addEventListener(
            "change",
            updateSelectedExam
        );


        /* --------------------------------------
           BUTTONS
        -------------------------------------- */

        setupButtonEvents();


        /* --------------------------------------
           SEARCH + DEPARTMENT FILTER
        -------------------------------------- */

        setupSeatingFilters();


        /* --------------------------------------
           INITIAL UI
        -------------------------------------- */

        updateStatistics();

        updateAdditionalStatus();

        renderSeatingTable();


        console.log(
            "================================"
        );

        console.log(
            "✅ Seating Generator Ready"
        );

        console.log(
            "Master Students:",
            masterStudents.length
        );

        console.log(
            "Rooms:",
            rooms.length
        );

        console.log(
            "Examinations:",
            exams.length
        );

        console.log(
            "================================"
        );

    }
);